use crate::utils::*;
use crate::logging::*;
use std::time::Instant;

pub async fn run_crawler(domain: &str) -> Result<(), Box<dyn std::error::Error>> {
    let sitemap_urls = match get_sitemaps_from_robots(domain).await {
        Ok(urls) if !urls.is_empty() => urls,
        _ => try_load_sitemap_xml(domain).await.unwrap_or_else(|_| vec![]),
    };

    let urls = if sitemap_urls.is_empty() {
        crawl_with_spider(domain).await?
    } else {
        extract_urls_from_sitemaps(sitemap_urls).await?
    };

    let mode = get_mode_from_config(domain).unwrap_or("SSR".into());
    let worker_id = get_worker_id();

    for url in urls {
        let start = Instant::now();

        let html = fetch_html_with_spider(&url, &mode).await?;
        let markdown = convert_html_to_markdown(&html)?;

        let html_path = upload_to_gcs_gz(domain, &url, &html, "html").await?;
        let md_path = upload_to_gcs_gz(domain, &url, &markdown, "md").await?;

        save_metadata_to_scylla(domain, &url, &html_path, &md_path).await?;

        log_event_to_quickwit("html_fetched", domain, &url, 200, &html_path, &worker_id, &mode, start.elapsed().as_millis()).await;
    }

    Ok(())
}
