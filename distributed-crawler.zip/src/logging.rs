pub async fn log_event_to_quickwit(
    event: &str,
    domain: &str,
    url: &str,
    status_code: u16,
    gcs_path: &str,
    worker_id: &str,
    mode: &str,
    duration_ms: u128,
) {
    println!(
        "{{\"@timestamp\":\"{}\",\"event\":\"{}\",\"domain\":\"{}\",\"url\":\"{}\",\"status_code\":{},\"gcs_path\":\"{}\",\"worker_id\":\"{}\",\"mode\":\"{}\",\"duration_ms\":{}}}",
        chrono::Utc::now().to_rfc3339(), event, domain, url, status_code, gcs_path, worker_id, mode, duration_ms
    );
}

pub fn get_mode_from_config(_domain: &str) -> Option<String> {
    Some("SSR".to_string())
}

pub fn get_worker_id() -> String {
    "pod-01".to_string()
}
