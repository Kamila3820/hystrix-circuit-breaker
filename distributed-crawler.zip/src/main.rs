mod crawler;
mod worker;
mod utils;
mod logging;

#[tokio::main]
async fn main() {
    if let Err(e) = worker::start_worker().await {
        eprintln!("Worker crashed: {}", e);
    }
}
