use quick_xml::de::from_str;
use serde::Deserialize;
use reqwest::get;

#[derive(Debug, Deserialize)]
struct UrlSet {
    #[serde(rename = "url")]
    urls: Vec<UrlEntry>,
}

#[derive(Debug, Deserialize)]
struct UrlEntry {
    loc: String,
}

pub async fn get_sitemaps_from_robots(domain: &str) -> Result<Vec<String>, Box<dyn std::error::Error>> {
    let txt = get(format!("https://{}/robots.txt", domain)).await?.text().await?;
    let sitemaps = txt.lines()
        .filter_map(|line| line.strip_prefix("Sitemap: "))
        .map(|s| s.trim().to_string())
        .collect();
    Ok(sitemaps)
}

pub async fn try_load_sitemap_xml(domain: &str) -> Result<Vec<String>, Box<dyn std::error::Error>> {
    let url = format!("https://{}/sitemap.xml", domain);
    let res = get(&url).await?;
    if res.status().is_success() {
        let body = res.text().await?;
        let sitemap: UrlSet = from_str(&body)?;
        Ok(sitemap.urls.into_iter().map(|u| u.loc).collect())
    } else {
        Ok(vec![])
    }
}

pub async fn extract_urls_from_sitemaps(sitemaps: Vec<String>) -> Result<Vec<String>, Box<dyn std::error::Error>> {
    let mut urls = vec![];
    for sm in sitemaps {
        let body = get(&sm).await?.text().await?;
        if body.contains("<urlset") {
            if let Ok(parsed): Result<UrlSet, _> = from_str(&body) {
                urls.extend(parsed.urls.into_iter().map(|u| u.loc));
            }
        }
    }
    Ok(urls)
}
