use spider::Website;
use reqwest;

pub async fn crawl_with_spider(domain: &str) -> Result<Vec<String>, Box<dyn std::error::Error>> {
    let mut website = Website::new(&format!("https://{}", domain));
    website.configuration.respect_robots_txt = true;
    website.configuration.crawl_subdomains = false;
    website.configuration.max_depth = Some(2);
    website.crawl().await;
    let urls = website.get_links().into_iter().collect();
    Ok(urls)
}

pub async fn fetch_html_with_spider(url: &str, _mode: &str) -> Result<String, Box<dyn std::error::Error>> {
    let html = reqwest::get(url).await?.text().await?;
    Ok(html)
}

pub fn convert_html_to_markdown(html: &str) -> Result<String, Box<dyn std::error::Error>> {
    Ok(html2md::parse_html(html))
}
