use sha2::{Sha256, Digest};
use std::io::Write;
use flate2::write::GzEncoder;
use flate2::Compression;
use base64::{engine::general_purpose, Engine as _};

pub async fn upload_to_gcs_gz(domain: &str, url: &str, content: &str, typ: &str) -> Result<String, Box<dyn std::error::Error>> {
    let hash = Sha256::digest(url.as_bytes());
    let slug = general_purpose::URL_SAFE_NO_PAD.encode(&hash);
    let path = format!("gs://your-bucket/{}/{}/{slug}.{}.gz", domain, typ, typ);

    let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
    encoder.write_all(content.as_bytes())?;
    let _gzipped = encoder.finish()?;

    Ok(path)
}

pub async fn save_metadata_to_scylla(domain: &str, url: &str, html: &str, md: &str) -> Result<(), Box<dyn std::error::Error>> {
    println!("[SCYLLADB] domain={} url={} html={} md={}", domain, url, html, md);
    Ok(())
}
