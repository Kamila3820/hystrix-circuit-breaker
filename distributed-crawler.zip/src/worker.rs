use crate::crawler::run_crawler;
pub async fn start_worker() -> Result<(), Box<dyn std::error::Error>> {
    // Example domain list (you can connect to NATS later)
    let domains = vec!["example.com", "rust-lang.org"];
    for domain in domains {
        run_crawler(domain).await?;
    }
    Ok(())
}
